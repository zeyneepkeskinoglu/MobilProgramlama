package com.example.quiz



import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import com.example.quiz.SoruSabit
import com.example.quiz.R
import com.example.quiz.RaporActivity
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_sorular.*
import kotlin.concurrent.timer

class SorularActivity : AppCompatActivity() {
    var soruListe = SoruSabit.getSorular()
    var kacincisoru:Int=0
    var pgDegeri = 0;
    var secilenYanit:MutableList<String> = mutableListOf("","","","","","","","","")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sorular)
        sayısure()
        val isim = intent.getStringExtra("isim")
        SoruGoster()


    }


    private fun sayısure(){

        val timer = object: CountDownTimer(30000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                pgDegeri++;
                tvSayac.setText(pgDegeri.toString())
            }
            override fun onFinish() {kacincisoru++
                SoruGoster()
                pgDegeri=0;
                sayısure()

            }


        }
        timer.start()
    }

    private fun SoruGoster(){
        var soru=soruListe[kacincisoru]
        tvSoru.setText(soru.metin)
        tvCevapa.setText(soru.a)
        tvCevapb.setText(soru.b)
        tvCevapc.setText(soru.c)
        tvCevapd.setText(soru.d)



        isaretle()
    }




    private fun isaretle(){
        tvCevapa.setBackgroundColor(Color.parseColor("#FFFFFF"))
        tvCevapb.setBackgroundColor(Color.parseColor("#FFFFFF"))
        tvCevapc.setBackgroundColor(Color.parseColor("#FFFFFF"))
        tvCevapd.setBackgroundColor(Color.parseColor("#FFFFFF"))
        tvCevape.setBackgroundColor(Color.parseColor("#FFFFFF"))
        when(secilenYanit[kacincisoru]){
            "a" -> tvCevapa.setBackgroundColor(Color.parseColor("#FFFF00"))
            "b" -> tvCevapb.setBackgroundColor(Color.parseColor("#FFFF00"))
            "c" -> tvCevapc.setBackgroundColor(Color.parseColor("#FFFF00"))
            "d" -> tvCevapd.setBackgroundColor(Color.parseColor("#FFFF00"))
            "e" -> tvCevape.setBackgroundColor(Color.parseColor("#FFFF00"))
        }


    }
    public fun secim(v: View){
        when(v.id){
            R.id.tvCevapa -> secilenYanit[kacincisoru] = "a"
            R.id.tvCevapb -> secilenYanit[kacincisoru] = "b"
            R.id.tvCevapc -> secilenYanit[kacincisoru] = "c"
            R.id.tvCevapd -> secilenYanit[kacincisoru] = "d"
            R.id.tvCevape -> secilenYanit[kacincisoru] = "e"
        }
        isaretle()
    }

    public fun bitir(v: View){
        var dogrusayisi=0
        var yanlissayisi=0
        var bossayisi=0
        for (i in 0..(soruListe.size-1))
            if(secilenYanit[i] == soruListe[i].dogru){
                dogrusayisi++
            }else if(secilenYanit[i]=="") {
                bossayisi++
            }else {
                yanlissayisi++
            }
        val intent = Intent(this, RaporActivity::class.java)
        intent.putExtra("dogrusayisi",dogrusayisi.toString())
        intent.putExtra("yanlissayisi",yanlissayisi.toString())
        intent.putExtra("bossayisi",bossayisi.toString())

        startActivity(intent)
        finish()
    }

    public fun ileri(v: View){
        if(kacincisoru<soruListe.size-1){
            kacincisoru++
            SoruGoster()
            sayısure()
            pgDegeri=0;




        }

    }


}