package com.example.quiz

import java.util.*

object SoruSabit {
    fun getSorular():ArrayList<Soru>{
        var liste: ArrayList<Soru> = ArrayList<Soru>()
        var s1: Soru=Soru(
            1,"'Kimseye etmem şikayet' kimin şarkısıdır?",
            "Ayla Dikmen",
            "Bob Dylan",
            "Müzeyyen Senar",
            "Fikret Kızılok",
            "c"
           )
        liste.add(s1);
        liste.add(
            Soru(
                2,"9.senfoni kimin eseridir?",
                "Mozart",
                "Beethoven",
                "Faure",
                "Bach",
                "b")
        )
        liste.add(
            Soru(
                3,"Dokunmadan çalınan enstrüman hangisidir?",
                "Theremin",
                "Keman",
                "Yay Bahar",
                "Hangdrum",
                "a")
        )
        liste.add(
            Soru(
                4,"Caz müziğin en ünlü ismi kimdir?",
                "Eric Clapton",
                "Queen",
                "Louis Armstrong",
                "Dio",
                "c")
        )
        liste.add(
            Soru(
                5,"'Şimdi uzaklardasın' kimin şarkısıdır?",
                "Özdemir Erdoğan",
                "Tanju Okan",
                "Münir Nurettin ",
                "Zeki Müren",
                "a")
        )

        return liste
    }
}