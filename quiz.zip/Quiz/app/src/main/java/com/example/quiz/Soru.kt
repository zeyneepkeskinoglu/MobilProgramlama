package com.example.quiz

data class Soru(
    val id:Int,
    val metin:String,
    val a:String,
    val b:String,
    val c:String,
    val d:String,

    val dogru:String
)