package com.example.quiz


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.quiz.R
import kotlinx.android.synthetic.main.activity_rapor.*

class RaporActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rapor)
        dogrusayı.setText(intent.getStringExtra("dogrusayisi"))
        yanlıssayı.setText(intent.getStringExtra("yanlissayisi"))
        bossayı.setText(intent.getStringExtra("bossayisi"))
    }
}