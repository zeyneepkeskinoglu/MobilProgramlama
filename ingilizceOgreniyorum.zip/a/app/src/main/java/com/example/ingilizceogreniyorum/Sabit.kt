package com.example.ingilizceogreniyorum

object Sabit {
    fun getSorular():ArrayList<Soru>{
        var liste :ArrayList<Soru> = ArrayList<Soru>()
        var s1 : Soru=Soru(
            1,"Resimde ne var ?",
            R.drawable.mavibalon,
            "Blue Balloon",
            "Yellow Car",
            "Green Apple",
            "Red Gloves",
            "a"
        )
        liste.add(s1)
        liste.add(
            Soru(
            2,"Resimde ne var ?",
            R.drawable.eldiven,
            "Blue Balloon",
            "Yellow Car",
            "Green Apple",
            "Red Gloves",
            "d"
        )
        )
        liste.add(
            Soru(
                3,"Resimde ne var ?",
                R.drawable.car,
                "Blue Balloon",
                "Yellow Car",
                "Green Apple",
                "Red Gloves",
                "b"
            )
        )
        liste.add(
            Soru(
                4,"Resimde ne var ?",
                R.drawable.elam,
                "Blue Balloon",
                "Yellow Car",
                "Green Apple",
                "Red Gloves",
                "c"
            )
        )
        liste.add(
            Soru(
                5,"Resimde ne var ?",
                R.drawable.morinek,
                "Blue Balloon",
                "Purple Cow",
                "Green Apple",
                "Red Gloves",
                "b"
            )
        )
        liste.add(
            Soru(
                6,"Resimde ne var ?",
                R.drawable.cat,
                "Orange Cat",
                "Yellow Car",
                "Green Apple",
                "Red Gloves",
                "a"
            )
        )
        liste.add(
            Soru(
                7,"Resimde ne var ?",
                R.drawable.dog,
                "Blue Balloon",
                "Yellow Car",
                "Green Apple",
                "White Dog",
                "d"
            )
        )
        liste.add(
            Soru(
                8,"Resimde ne var ?",
                R.drawable.black,
                "Black Dress",
                "Yellow Car",
                "Green Apple",
                "White Dog",
                "a"
            )
        )
        liste.add(
            Soru(
                9,"Resimde ne var ?",
                R.drawable.pink,
                "Black Dress",
                "Yellow Car",
                "Pink Glasses",
                "White Dog",
                "c"
            )
        )
        liste.add(
            Soru(
                10,"Resimde ne var ?",
                R.drawable.gri,
                "Black Dress",
                "Gray Rabbit",
                "Pink Glasses",
                "White Dog",
                "b"
            )
        )
        liste.add(
            Soru(
                11,"Resimde ne var ?",
                R.drawable.kvrnk,
                "Black Dress",
                "Gray Rabbit",
                "Pink Glasses",
                "Brown Bear",
                "d"
            )
        )


   return liste
    }
}