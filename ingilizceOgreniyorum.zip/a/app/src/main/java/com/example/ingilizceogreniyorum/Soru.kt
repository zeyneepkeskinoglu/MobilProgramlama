package com.example.ingilizceogreniyorum

data class Soru(
    val id : Int,
    val metin:String,
    val resim :Int,
    val a : String,
    val b : String,
    val c : String,
    val d : String,
    val dogru : String
)
