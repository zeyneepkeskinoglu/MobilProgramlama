package com.example.ingilizceogreniyorum

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_sorular.*

class SorularActivity : AppCompatActivity() {
    var soruListe = Sabit.getSorular()
    var kacinciSoru : Int=0
    var secilenYanit : MutableList<String> = mutableListOf("","","","","","","","","","","")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sorular)
        val isim = intent.getStringExtra("isim")
        tvIsim.setText(isim)
        tvsoruno.setText("${kacinciSoru+1}/${soruListe.size}")
        soruGoster()
    }
    private fun soruGoster(){
        var soru = soruListe[kacinciSoru]
        tvsoru.setText(soru.metin)
        tvcevapA.setText(soru.a)
        tvcevapB.setText(soru.b)
        tvcevapC.setText(soru.c)
        tvcevapD.setText(soru.d)
        ivresim.setImageResource(soru.resim)
        isaretle()
    }
    private fun isaretle(){
        tvcevapA.setBackgroundColor(Color.parseColor("#FFFFFF"))
        tvcevapB.setBackgroundColor(Color.parseColor("#FFFFFF"))
        tvcevapC.setBackgroundColor(Color.parseColor("#FFFFFF"))
        tvcevapD.setBackgroundColor(Color.parseColor("#FFFFFF"))
        when(secilenYanit[kacinciSoru]){
            "a" -> tvcevapA.setBackgroundColor(Color.parseColor("#FFFF00"))
            "b" -> tvcevapB.setBackgroundColor(Color.parseColor("#FFFF00"))
            "c" -> tvcevapC.setBackgroundColor(Color.parseColor("#FFFF00"))
            "d" -> tvcevapD.setBackgroundColor(Color.parseColor("#FFFF00"))
        }
        tvsoruno.setText(kacinciSoru.toString()+"/8")
    }
    public fun secim(v:View){
        when(v.id){
            R.id.tvcevapA -> secilenYanit[kacinciSoru] = "a"
            R.id.tvcevapB -> secilenYanit[kacinciSoru] = "b"
            R.id.tvcevapC -> secilenYanit[kacinciSoru] = "c"
            R.id.tvcevapD -> secilenYanit[kacinciSoru] = "d"
        }
        isaretle()
        if (kacinciSoru == 10){
            bitir(v)
        }else{
            ileri(v)
        }
    }
    public fun geri(v:View){
        if (kacinciSoru>0){
            kacinciSoru--
            soruGoster()
        }

    }
    public fun ileri(v:View){
        if (kacinciSoru < soruListe.size-1){
            kacinciSoru++
            soruGoster()
        }

    }
    public fun bitir(v:View){
        var dogruSayisi =0
        var yanlisSayisi=0
        var bosSayisi = 0
        for (i in 0..(soruListe.size-1)){
            if (secilenYanit[i] == soruListe[i].dogru){
                dogruSayisi++
            }else if (secilenYanit[i]==""){
                bosSayisi++
            }else{
                yanlisSayisi++
            }

    }
        val intent = Intent(this,RaporAktivity::class.java)
        intent.putExtra("dogruSayisi",dogruSayisi.toString())
        intent.putExtra("yanlisSayisi",yanlisSayisi.toString())
        intent.putExtra("bosSayisi",bosSayisi.toString())
        startActivity(intent)
        finish()

}}