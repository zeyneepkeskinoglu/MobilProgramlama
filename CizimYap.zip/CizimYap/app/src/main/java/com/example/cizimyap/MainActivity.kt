package com.example.cizimyap

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.app.Instrumentation
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.media.MediaScannerConnection
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.dialog_cizgi_kalinligi.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    var renkButonu:ImageButton? = null;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        renkButonu = ll_renkler.getChildAt(0) as ImageButton;
        cv_sahne.renkAyarla(Color.parseColor(renkButonu!!.tag.toString()))
        renkButonu!!.setImageDrawable(
            ContextCompat.getDrawable(this,R.drawable.renk_kutusu_farkli)
        )

    }

    fun onCizgiKalingligiDegistir(eleman: View){
        val kalinlikDialog = Dialog(this)
        kalinlikDialog.setContentView(R.layout.dialog_cizgi_kalinligi)
        kalinlikDialog.setTitle("Çizgi Kalınlığı")
        kalinlikDialog.kucuk.setOnClickListener{
            cv_sahne.cizgiKalinligiAyarla(10F)
            kalinlikDialog.dismiss()
        }
        kalinlikDialog.orta.setOnClickListener{
            cv_sahne.cizgiKalinligiAyarla(20F)
            kalinlikDialog.dismiss()
        }
        kalinlikDialog.buyuk.setOnClickListener{
            cv_sahne.cizgiKalinligiAyarla(30F)
            kalinlikDialog.dismiss()
        }

        kalinlikDialog.show()
    }
    fun renkDegistir(eleman: View){
        cv_sahne.renkAyarla(Color.parseColor(eleman.tag.toString()))
        renkButonu!!.setImageDrawable(
            ContextCompat.getDrawable(this,R.drawable.renk_kutusu)
        )
        renkButonu=eleman as ImageButton
        renkButonu!!.setImageDrawable(
            ContextCompat.getDrawable(this,R.drawable.renk_kutusu_farkli)
        )
    }
    fun onGeri(g: View){
        cv_sahne.geriAl()
    }
    fun onIleri(g: View){
        cv_sahne.ileriAl()
    }
    fun onGalleryClick(g: View){
        if(izniVarMi()){
            val resimSec = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(resimSec, RESIM_SEC)
        }else{
            izinIste()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(resultCode == Activity.RESULT_OK) {
            if (requestCode == RESIM_SEC) {
                try{
                    if(data!!.data !==null){
                        iv_arkaplan.setImageURI(data!!.data)
                        Toast.makeText(this,"Resim yüklendi..",Toast.LENGTH_LONG).show()
                    }else{
                        Toast.makeText(this,"Resim yüklenemedi. Birşeyler ters gitt.",Toast.LENGTH_LONG).show()
                    }
                }catch (e: Exception){
                    e.printStackTrace()
                }
            }
        }
    }
    private fun izinIste(){
        ActivityCompat.requestPermissions(this,
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE),DISK_IZIN_KODU)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode==DISK_IZIN_KODU){
            if(grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this,"İzin verdiniz..",Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(this,"Maalesef izin vermediniz..",Toast.LENGTH_LONG).show()
            }
        }

    }
    private fun izniVarMi(): Boolean{
        val sonuc = ContextCompat.checkSelfPermission(this,Manifest.permission.READ_EXTERNAL_STORAGE)
        return sonuc == PackageManager.PERMISSION_GRANTED
    }
    fun onSaveClick(g: View){
        if(izniVarMi()){
            val resimBitmap:Bitmap = Bitmap.createBitmap(fl_cizim.width, fl_cizim.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(resimBitmap)
            val bgDrawable = fl_cizim.background
            if(bgDrawable!=null){
                bgDrawable.draw(canvas)
            }else{
                canvas.drawColor(Color.WHITE)
            }
            fl_cizim.draw(canvas)
            val bytes = ByteArrayOutputStream()
            resimBitmap.compress(Bitmap.CompressFormat.JPEG, 90, bytes)
            val f = File(externalCacheDir!!.absoluteFile.toString()
                    +File.separator+"CizimYap_"+System.currentTimeMillis()/1000+".jpg")
            val fo = FileOutputStream(f)
            fo.write(bytes.toByteArray())
            fo.close()



            val fileUri: Uri? = try {
                FileProvider.getUriForFile(
                    this,
                    "com.example.cizimyap.fileprovider",
                    f)
            } catch (e: IllegalArgumentException) {
                Log.e("File Selector",
                    "The selected file can't be shared: $f")
                null
            }
            if(fileUri != null) {
                Toast.makeText(this, "URI:" + fileUri!!.toString(), Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(this, "URI: boş" , Toast.LENGTH_LONG).show()
            }
            val intent = Intent()
            intent.action = Intent.ACTION_SEND
            intent.putExtra(Intent.EXTRA_STREAM, fileUri);
            intent.type = "*/*"
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)


            startActivity(
                Intent.createChooser(
                    intent,
                    "Paylaş"
                )
            )



        }else{
            izinIste()
        }
    }
    companion object {
        private const val DISK_IZIN_KODU = 11
        private const val RESIM_SEC = 22
    }
}