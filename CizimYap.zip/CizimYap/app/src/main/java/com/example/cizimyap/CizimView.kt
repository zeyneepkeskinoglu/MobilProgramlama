package com.example.cizimyap

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.random.Random

class CizimView(context: Context, attrs: AttributeSet): View(context,attrs) {
    private var yol:OzelPath? = null
    private var boya:Paint? = null
    private var renk = Color.BLUE
    private var cizgiKalinligi:Float = 20f
    private var yollar = ArrayList<OzelPath>()
    private var geriAlinmis = ArrayList<OzelPath>()

    init{

    }
    fun geriAl(){
        if(yollar.size>0) {
            geriAlinmis.add(yollar.removeAt(yollar.size - 1))
            invalidate()
        }
    }
    fun ileriAl(){
        if(geriAlinmis.size>0) {
            yollar.add(geriAlinmis.removeAt(geriAlinmis.size - 1))
            invalidate()
        }
    }
    fun cizgiKalinligiAyarla(deger:Float){
        cizgiKalinligi = deger
    }
    fun renkAyarla(c:Int){
        renk = c
    }
    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        for( i in 0..(yollar.size-1)){
            boya = Paint()
            boya!!.style = Paint.Style.STROKE
            boya!!.strokeJoin = Paint.Join.ROUND
            boya!!.strokeCap = Paint.Cap.ROUND
            boya!!.strokeWidth = yollar[i].cizgiKalinligi
            boya!!.color = yollar[i].renk
            canvas!!.drawPath(yollar[i],boya!!)
        }
        if(yol != null){
            if(boya != null){
                boya = Paint()
                boya!!.style = Paint.Style.STROKE
                boya!!.strokeJoin = Paint.Join.ROUND
                boya!!.strokeCap = Paint.Cap.ROUND
                boya!!.strokeWidth = cizgiKalinligi
                boya!!.color = renk
                canvas!!.drawPath(yol!!,boya!!)
            }
        }

    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        val xKonum = event!!.x
        val yKonum = event!!.y
        when(event!!.action){
            MotionEvent.ACTION_DOWN -> {
                geriAlinmis.clear()
                yol = OzelPath(renk,cizgiKalinligi)
                yol!!.moveTo(xKonum,yKonum)
            }
            MotionEvent.ACTION_MOVE -> {
                yol!!.lineTo(xKonum,yKonum)
            }
            MotionEvent.ACTION_UP -> {
                yollar.add(yol!!)
                yol = null
            }
        }
        invalidate()
        return true
    }

    internal inner class OzelPath(var renk:Int, var cizgiKalinligi:Float): Path(){}
}